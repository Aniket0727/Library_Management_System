from flask import Blueprint, request, jsonify
from models import db, Book, Member
from functools import wraps

library_routes = Blueprint('library', __name__)

# Dummy token-based authentication
def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        token = request.headers.get('Authorization')
        if token != "Bearer my_secure_token":
            return jsonify({"message": "Token is missing or invalid!"}), 403
        return f(*args, **kwargs)
    return decorated

# CRUD for Books
@library_routes.route('/books', methods=['POST'])
@token_required
def add_book():
    data = request.json
    new_book = Book(title=data['title'], author=data['author'], published_year=data.get('published_year'))
    db.session.add(new_book)
    db.session.commit()
    return jsonify({"message": "Book added successfully"}), 201

@library_routes.route('/books/<int:id>', methods=['GET'])
@token_required
def get_book(id):
    book = Book.query.get_or_404(id)
    return jsonify({"id": book.id, "title": book.title, "author": book.author, "published_year": book.published_year})

@library_routes.route('/books/<int:id>', methods=['PUT'])
@token_required
def update_book(id):
    data = request.json
    book = Book.query.get_or_404(id)
    book.title = data['title']
    book.author = data['author']
    book.published_year = data.get('published_year')
    db.session.commit()
    return jsonify({"message": "Book updated successfully"})

@library_routes.route('/books/<int:id>', methods=['DELETE'])
@token_required
def delete_book(id):
    book = Book.query.get_or_404(id)
    db.session.delete(book)
    db.session.commit()
    return jsonify({"message": "Book deleted successfully"})

@library_routes.route('/books', methods=['GET'])
@token_required
def search_books():
    query = request.args.get('q')
    page = int(request.args.get('page', 1))
    per_page = int(request.args.get('per_page', 5))

    books_query = Book.query
    if query:
        books_query = books_query.filter((Book.title.contains(query)) | (Book.author.contains(query)))

    books = books_query.paginate(page=page, per_page=per_page, error_out=False).items
    result = [{"id": book.id, "title": book.title, "author": book.author, "published_year": book.published_year} for book in books]
    return jsonify(result)
